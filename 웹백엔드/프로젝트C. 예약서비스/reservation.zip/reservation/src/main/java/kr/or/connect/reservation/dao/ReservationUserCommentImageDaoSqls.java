package kr.or.connect.reservation.dao;

public class ReservationUserCommentImageDaoSqls {
	public static final String RESERVATION_USER_COMMENT_IMAGE__SELECT_BY__RESERVATION_USER_COMMENT_ID = "SELECT * FROM reservation_user_comment_image WHERE reservation_user_comment_id = :reservationUserCommentId";
}
