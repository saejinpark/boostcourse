package kr.or.connect.reservation.dto;

import lombok.Data;

@Data
public class DisplayInfoImage {
	private Integer id;
	private Integer displayInfoId;
	private Integer fileId;
}
