package kr.or.connect.reservation.dao;

public class DisplayInfoDaoSqls {

	public static final String DISPLAY_INFO__SELECT_ALL = "SELECT * FROM display_info";
	public static final String DISPLAY_INFO__SELECT_BY__ID = "SELECT * FROM display_info WHERE id = :id";

}
