package kr.or.connect.reservation.dao;

public class DisplayInfoImageDaoSqls {
	public static final String DISPLAY_INFO_IMAGE__SELECT_BY__DISPLAY_INFO_ID = "SELECT * FROM display_info_image WHERE display_info_id = :displayInfoId";
}
