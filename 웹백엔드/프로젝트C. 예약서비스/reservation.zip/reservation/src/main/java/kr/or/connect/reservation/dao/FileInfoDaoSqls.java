package kr.or.connect.reservation.dao;

public class FileInfoDaoSqls {
	public static final String FILE_INFO__SELECT_BY__FILE_ID = "SELECT * FROM file_info WHERE id = :fileId";
}
