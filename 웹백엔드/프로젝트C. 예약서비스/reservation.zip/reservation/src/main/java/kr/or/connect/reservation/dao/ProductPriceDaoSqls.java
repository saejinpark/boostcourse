package kr.or.connect.reservation.dao;

public class ProductPriceDaoSqls {
	public static final String SELECT_BY_PRODUCTID = "SELECT * FROM product_price WHERE product_id = :productId;";
}
