package kr.or.connect.reservation.dao;

public class PromotionDaoSqls {
	public static final String PROMOTION__SELECT_ALL = "SELECT * FROM promotion";
}