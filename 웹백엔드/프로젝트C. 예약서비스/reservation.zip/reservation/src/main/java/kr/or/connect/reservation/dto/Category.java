package kr.or.connect.reservation.dto;

import lombok.Data;

@Data
public class Category {
	private Integer id;
	private String name;
}
