package kr.or.connect.reservation.dto;

import lombok.Data;

@Data
public class Category {
	private int id;
	private String name;
	private int count;
}
