package kr.or.connect.reservation.dto;

import lombok.Data;

@Data
public class Promotion {
	private Integer id;
	private Integer productId;
}
