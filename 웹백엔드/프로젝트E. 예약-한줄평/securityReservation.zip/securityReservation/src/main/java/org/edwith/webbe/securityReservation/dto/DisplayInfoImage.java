package org.edwith.webbe.securityReservation.dto;

import lombok.Data;

@Data
public class DisplayInfoImage {
	private int id;
	private int displayInfoId;
	private int fileId;
	private String fileName;
	private String saveFileName;
	private String contentType;
	private int deleteFlag;
	private String createDate;
	private String modifyDate;
}
