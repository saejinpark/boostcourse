package org.edwith.webbe.securityReservation.dto;

import lombok.Data;

@Data
public class Category {
	private int id;
	private String name;
	private int count;
}
