use BusinessCard;
create table BusinessCard(
    name varchar(20),
    phone char(13),
    companyName varchar(20),
    createDate long
);