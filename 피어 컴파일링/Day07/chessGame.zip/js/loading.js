const hideLoading = () => {
    const loading = document.querySelector(".loading");
    loading.classList.add("blind");
};
hideLoading();
