package org.edwith.webbe.reservation.dao;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.RequiredArgsConstructor;

import org.edwith.webbe.reservation.config.ApplicationConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ApplicationConfig.class})
@RequiredArgsConstructor
public class ReservationCommentDaoTest {
	private final ReservationCommentDao reservationCommentDao;

	@Test
    public void execute() throws Exception{
		assertNotNull("getComments(1, 1) should be not null", reservationCommentDao.getComments(1, 1));
		assertNotNull("getComments(1, 1, 1) should be not null", reservationCommentDao.getComments(1, 1, 1));
		assertNotNull("selectAvgScoreByProductId(1) should be not null", reservationCommentDao.selectAvgScoreByProductId(1));
		assertNotNull("selectCountAll() should be not null", reservationCommentDao.selectCountAll());
		assertNotNull("selectCountProductId(1) should be not null", reservationCommentDao.selectCountDisplayInfoId(1));
	}
}
