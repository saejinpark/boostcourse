package org.edwith.webbe.reservation.controller;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.edwith.webbe.reservation.dto.FileInfo;
import org.edwith.webbe.reservation.service.CommentsService;
import org.edwith.webbe.reservation.service.FilesService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/comments")
@RequiredArgsConstructor
public class CommentApiController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private final CommentsService commentsService;
	private final FilesService filesService;

	@GetMapping("")
	@ApiOperation(value = "댓글 목록", notes = "댓글 목록 구하기")
	public Map<String, Object> getComments(
			@ApiParam(value = "프로덕트 아이디") @RequestParam(required = false) Integer productId,
			@ApiParam(value = "시작지점") @RequestParam(defaultValue = "0") Integer start) {
		return commentsService.getComments(productId, start);
	}

	@PostMapping("")
	@ApiOperation(value = "댓글 등록", notes = "댓글 등록하기")
	public HashMap<String, Object> postComments(HttpServletRequest request,
			@ApiParam(value = "reservationInfoId") @RequestParam Integer reservationInfoId,
			@ApiParam(value = "score") @RequestParam Integer score,
			@ApiParam(value = "comment") @RequestParam String comment,
			@ApiParam(value = "file") @RequestPart(required = false) MultipartFile file) {

		HashMap<String, Object> result = new HashMap<>();

		HttpSession session = request.getSession(false);
		String email = (String) session.getAttribute("email");
		
		try {
			commentsService.postComments(reservationInfoId, score, email, comment, file);
			result.put("result", "success");
		} catch (Exception e) {
			result.put("result", "fail");
		}

		return result;
	}
	

	@GetMapping(value = "file/{id}", produces = {"image/jpeg", "image/png" })
	@ResponseBody
	@ApiOperation(value = "댓글 이미지", notes = "댓글 이미지")
	public byte[] commentImage(@PathVariable Integer id) {
		FileInfo fileInfo = filesService.getFile(id);
		FileInputStream fis = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		logger.info(fileInfo.getSaveFileName());
		try {
			fis = new FileInputStream("/" + fileInfo.getSaveFileName());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		int readCount = 0;
		byte[] buffer = new byte[1024];
		byte[] fileArray = null;

		try {
			while ((readCount = fis.read(buffer)) != -1) {
				baos.write(buffer, 0, readCount);
			}

			fileArray = baos.toByteArray();
			fis.close();
			baos.close();

		} catch (IOException e) {
			throw new RuntimeException("file Error");
		}
		
		return fileArray;
	}
	
}
