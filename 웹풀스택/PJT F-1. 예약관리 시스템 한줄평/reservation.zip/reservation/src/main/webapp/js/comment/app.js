async function App(reservationInfoId, displayInfoId) {
  load(displayInfoId);
  const [initBooking, booking] = generateBooking()
  initBooking(reservationInfoId);

  bkBtn.addEventListener("click", bkBtnHandler.bind({booking}));
}
