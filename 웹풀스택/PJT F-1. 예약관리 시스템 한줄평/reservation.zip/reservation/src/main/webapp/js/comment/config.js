const reviewHeader = document.querySelector(".review_header");
const title = reviewHeader.querySelector(".title");
const raiting = document.querySelector(".rating");
const ratingRdos = raiting.querySelectorAll(".rating_rdo");
const starRank = raiting.querySelector(".star_rank");
const reviewWrite = document.querySelector(".review_contents");
const reviewWriteInfo = document.querySelector(".review_write_info");
const reviewWriteTextarea = reviewWrite.querySelector("textarea");
reviewWriteTextarea.style.resize = "vertical";

const reviewWriteFooterWrap = document.querySelector(
  ".review_write_footer_wrap"
);
const guideReview = document.querySelector(".guide_review");
const commentLength = guideReview.querySelector("span");
const reviewImageFileOpenInput = document.querySelector("#reviewImageFileOpenInput");
const reviewPhoto = document.querySelector(".review_photos");
const lstThumb = reviewPhoto.querySelector(".lst_thumb");
const bkBtn = document.querySelector(".bk_btn");
const reviewPhotoItemTemplate = document.getElementById("reviewPhotoItem").innerText;