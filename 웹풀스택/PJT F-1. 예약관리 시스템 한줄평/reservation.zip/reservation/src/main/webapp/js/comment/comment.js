function generateRedirectReview() {
  let _displayInfoId = null;
  let _productId = null;
  function init(displayInfoId, productId) {
    _displayInfoId = displayInfoId;
    _productId = productId;
  }

  function redirect() {
    window.location.href = `/reservation/review?displayInfoId=${_displayInfoId}&productId=${_productId}`;
  }

  return [init, redirect];
}

let redirectReview = null;

function onreadystatechangeFunc(event, xhr, resolve, reject) {
  const { target } = event;
  if (target.readyState === XMLHttpRequest.DONE) {
    const { status } = target;
    if (status === 0 || (status >= 200 && status < 400)) {
      resolve(JSON.parse(xhr.response));
    }
    reject();
  }
}

function getDisplayInfo(xhr, displayInfoId) {
  return new Promise(function (resolve, reject) {
    xhr.open("GET", `api/products/${displayInfoId}`, false);
    xhr.onreadystatechange = function (e) {
      onreadystatechangeFunc(e, xhr, resolve, reject);
    };
    xhr.send();
  });
}

async function load(displayInfoId) {
  const xhr = new XMLHttpRequest();
  const displayInfo = await getDisplayInfo(xhr, displayInfoId);
  const { product } = displayInfo;
  const { id } = product;
  const [init, redirect] = generateRedirectReview();
  init(displayInfoId, id);
  redirectReview = redirect;
  const { description } = product;
  title.textContent = description;
}

function ratingRdoCheck(ratingRdo) {
  ratingRdo.checked = ratingRdo.value <= this;
}

function ratingRdosCheck(value) {
  ratingRdos.forEach(ratingRdoCheck.bind(value));
}

function ratingHandler(event) {
  const element = event.target;
  if (element.className === "rating_rdo") {
    classUtil.removeClass(starRank, "gray_star");
    ratingRdosCheck(element.value);
    starRank.textContent = element.value;
    if (element.value === "0") {
      classUtil.addClass(starRank, "gray_star");
    }
  }
}

function reviewWriteInfoHandler() {
  reviewWriteInfo.hidden = true;
}

function reviewWriteTextareaHandler() {
  reviewWriteTextarea.setCustomValidity("");
  commentLength.textContent = reviewWriteTextarea.value.length;
}

function generateBooking() {
  let reservationInfoId = null;

  function init(id) {
    reservationInfoId = id;
  }

  function booking() {
    const xhr = new XMLHttpRequest();

    const formData = new FormData();
    formData.append("reservationInfoId", reservationInfoId);
    formData.append("score", starRank.textContent);
    formData.append("comment", reviewWriteTextarea.value);
    formData.append("file", reviewImageFileOpenInput.files[0]);

    xhr.open("POST", `api/comments`, true);
    xhr.onreadystatechange = function (event) {
      const { target } = event;
      if (target.readyState === XMLHttpRequest.DONE) {
        const { status } = target;
        if (status === 0 || (status >= 200 && status < 400)) {
          const { result } = JSON.parse(xhr.response);
          if (result === "success") return redirectReview();
          return alert("등록 실패");
        }
      }
    };
    xhr.send(formData);
  }

  return [init, booking];
}

function bkBtnHandler() {
  if (reviewWriteTextarea.value.length < 5) {
    reviewWriteTextarea.setCustomValidity("리뷰는 5자 이상입니다");
    reviewWriteTextarea.reportValidity();
    reviewWriteTextarea.focus();
    return;
  }
  const { booking } = this;
  booking();
}

function reviewImageFileOpenInputHandler() {
  const files = reviewImageFileOpenInput.files;
  if (files.length === 0) return 0;
  const reader = new FileReader();
  reader.onload = function (e) {
    const bindTemplate = Handlebars.compile(reviewPhotoItemTemplate);
    const item = bindTemplate({ src: e.target.result });
    lstThumb.innerHTML = item;
    const closeBtn = lstThumb.querySelector(".item a");
    closeBtn.addEventListener("click", function () {
      lstThumb.innerHTML = "";
      reviewImageFileOpenInput.value = "";
    });
  };
  reader.readAsDataURL(files[0]);
}
