raiting.addEventListener("click", ratingHandler);
reviewWriteInfo.addEventListener("click", reviewWriteInfoHandler);
reviewWriteTextarea.addEventListener("input", reviewWriteTextareaHandler);
reviewImageFileOpenInput.addEventListener("input", reviewImageFileOpenInputHandler)