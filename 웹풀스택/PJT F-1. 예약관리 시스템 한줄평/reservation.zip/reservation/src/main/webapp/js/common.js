const classUtil = {
  addClass: function (elem, classString) {
    elem.className = elem.className
      .split(" ")
      .filter((name) => name != classString)
      .concat(classString)
      .join(" ");
  },

  removeClass: function (elem, classString) {
    elem.className = elem.className
      .split(" ")
      .filter((name) => name != classString)
      .join(" ");
  },

  toggleClass: function (elem, classString) {
    elem.className.includes(classString)
      ? this.removeClass(elem, classString)
      : this.addClass(elem, classString);
  },
};