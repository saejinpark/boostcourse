package aboutme;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TodayServlet
 */
@WebServlet("/today")
public class TodayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TodayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title>today</title></head>");
		out.println("<body>");

		String uri = request.getRequestURI();
		StringBuffer url = request.getRequestURL();
		String contentPath = request.getContextPath();
		String remoteAddr = request.getRemoteAddr();
		
        // 현재 날짜/시간        
		LocalDateTime now = LocalDateTime.now();
		// 현재 날짜/시간 출력
		System.out.println(now); // 2021-06-17T06:40:35.477667600
		// 년, 월(문자열, 숫자), 일(월 기준, 년 기준), 요일(문자열, 숫자), 시, 분, 초 구하기        
		int year = now.getYear();  // 연도        
		String month = now.getMonth().toString();  // 월(문자열)        
		int monthValue = now.getMonthValue();  // 월(숫자)
		int dayOfMonth = now.getDayOfMonth();  // 일(월 기준)
		int hour = now.getHour();
		int minute = now.getMinute();
		out.println("<header>");
		
		out.println("<a href='/aboutme'>메인화면</a>");
		out.println("</header>");

		out.println("<main>");

		out.println("<h1>");
		out.println("현재시간:" + year + "/" + monthValue + "/" + dayOfMonth + " " + hour + ":" + minute);
		out.println("</h1>");
		out.println("</main>");
		
		out.println("</body>");
		out.println("</html>");
	}
}
