package kr.or.connect.Todo.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.connect.Todo.dao.TodoDao;
import kr.or.connect.Todo.dto.Todo;

@WebServlet("/main")
public class MainServlet extends HttpServlet {
       
	private static final long serialVersionUID = -2134805763790425984L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		TodoDao todoDao = new TodoDao();
		
		List<Todo> todos = todoDao.getTodos();
		List<Todo> todoTypeList = new ArrayList<>();
		List<Todo> doingTypeList = new ArrayList<>();
		List<Todo> doneTypeList = new ArrayList<>();

		for (Todo todo : todos) {
			if ("TODO".equals(todo.getType())) {
				todoTypeList.add(todo);
			} else if ("DOING".equals(todo.getType())) {
				doingTypeList.add(todo);
			} else if ("DONE".equals(todo.getType())) {
				doneTypeList.add(todo);
			}
		}
		
		request.setAttribute("todoTypeList", todoTypeList);
		request.setAttribute("doingTypeList", doingTypeList);
		request.setAttribute("doneTypeList", doneTypeList);

		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/main.jsp");
		requestDispatcher.forward(request, response);
		
	}

}