package kr.or.connect.Todo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import kr.or.connect.Todo.dto.Todo;

public class TodoDao {
	private static final String DB_URL = "jdbc:mysql://localhost:3306/connectdb?serverTimezone=Asia/Seoul&useSSL=false&allowPublicKeyRetrieval=true";
	private static final String DB_USER = "connectuser";
	private static final String DB_PASSWD = "connect123!@#";

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Todo> getTodos() {
		List<Todo> list = new ArrayList<>();
		String sql = "SELECT id, title, name, sequence, type, regdate FROM todo ORDER BY regdate"; // order by 키워드는
																									// 기본적으로 오름차순 정렬
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWD);
				PreparedStatement ps = conn.prepareStatement(sql)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					Long id = rs.getLong("id");
					String title = rs.getString("title");
					String name = rs.getString("name");
					Integer sequence = rs.getInt("sequence");
					String type = rs.getString("type");
					String regDate = rs.getString("regDate");

					Todo todo = new Todo(id, title, name, sequence, type, regDate);
					list.add(todo);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return list;
	}

	public int addTodos(Todo todo) {
		int insertCount = 0;
		String sql = "INSERT INTO todo(title, name, sequence) VALUES (?, ?, ?)";

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWD);
				PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, todo.getTitle());
			ps.setString(2, todo.getName());
			ps.setInt(3, todo.getSequence());

			insertCount = ps.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return insertCount;
	}

	public int updateTodo(Todo todo) {
		int updateCount = 0;
		String sql = "UPDATE todo SET type = ? WHERE id = ?";

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWD);
				PreparedStatement ps = conn.prepareStatement(sql);) {

			ps.setString(1, todo.getType());
			ps.setLong(2, todo.getId());

			updateCount = ps.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return updateCount;
	}
}
