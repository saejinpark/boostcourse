package kr.or.connect.Todo.api;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.connect.Todo.dao.TodoDao;
import kr.or.connect.Todo.dto.Todo;

/**
 * Servlet implementation class TodoTypeServlet
 */
@WebServlet("/update/*")
public class TodoTypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8"); 
		
		Long id = Long.valueOf(request.getParameter("id"));
		String type = request.getParameter("type");
		
		Todo todo = new Todo();
		
		todo.setId(id);
		
		if(type.equals("TODO")) {
			todo.setType("DOING");	
		}else {
			todo.setType("DONE");
		}
		
		TodoDao todoDao = new TodoDao();
		
		int result = todoDao.updateTodo(todo);
		
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/plain");
		
		PrintWriter out = response.getWriter();
		
		if(result == 1) {
			out.println("success");
		}else {
			out.println("fail");
		}

		out.close();
		
	}

}
